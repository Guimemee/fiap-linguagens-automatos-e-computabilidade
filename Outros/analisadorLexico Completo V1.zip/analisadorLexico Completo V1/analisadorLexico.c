//Analisador L�xico
//Refer�ncia Apostila 2.1.1

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

char *codigo;
int tamanho,pos;
const char *ops="+-*/";

typedef struct{
	int tipo;  //Token
	int valor; //Lexema
}Token;

//A struct a seguir representa o N� da lista encadeada
struct lista{
	int tipo;
	int valor;
	int linha; //Ocorr�ncias
	int coluna;
	struct lista* next; //Ponteiro para pr�ximo n�
};
typedef struct lista Tabela;

Tabela* t;

#define TRUE 1
#define FALSE 0

#define TOK_NUM 0
#define TOK_OP 1
#define TOK_PONT 2

#define SOMA 0
#define SUB 1
#define MUL 2
#define DIV 3

#define PARESQ 0
#define PARDIR 1

Tabela* cria(void){
	return NULL;
}

Tabela* add(Tabela* t,Token *tok,int linha,int coluna){
	Tabela* no = (Tabela*) malloc(sizeof(Tabela));
	no->tipo = tok->tipo;
	no->valor = tok->valor;
	no->linha = linha;
	no->coluna = coluna;
	no->next = t;
	return no;
}

void inicializa_analise(char *prog){
	codigo=prog;
	tamanho=strlen(codigo);
	pos=0;
}

char le_caractere(void){
	char c;

	if(pos<tamanho){
		c=codigo[pos];
		pos++;
	}else
		c = -1; //a ver...

	return c;
}

int operador(char c){
	int res;

	switch(c){
		case '+':
			res=SOMA;
		break;
		case '-':
			res=SUB;
		break;
		case '*':
			res=MUL;
		break;
		case '/':
			res=DIV;
		break;
		default:
			res=-1; //a ver...
	}
	return res;
}

#define SOMA 0
#define SUB 1
#define MUL 2
#define DIV 3

Token *proximo_token(Token *tok){
	char c;
	char valor[200];
	int vpos=0;

	c=le_caractere();

	while(isspace(c)){
		c=le_caractere();
	}

	if(isdigit(c)){
		tok->tipo = TOK_NUM;
		valor[vpos++]=c;
		c=le_caractere();
		while(isdigit(c)){
			valor[vpos++]=c;
			c=le_caractere();
		}
		pos--;
		valor[vpos]='\0';
		tok->valor=atoi(valor);

		t=add(t,tok,2,3);

	}else if(strchr(ops,c)!=NULL){
		tok->tipo = TOK_OP;
		tok->valor = operador(c);
		t=add(t,tok,2,3);
	}else if(c=='('||c==')'){
		tok->tipo = TOK_PONT;
		tok->valor = (c=='('?PARESQ:PARDIR);
		t=add(t,tok,2,3);
	}else
		return NULL;

	return tok;
}

char *operador_str(int op){
	char *res;

	switch(op){
		case SOMA:
			res="SOMA";
		break;
		case SUB:
			res="SUB";
		break;
		case MUL:
			res="MUL";
		break;
		case DIV:
			res="DIV";
		break;
		default:
			res="NENHUM";
	}
	return res;
}

void imprime_token(Token *tok,FILE *fptr2){
	switch(tok->tipo){
		case TOK_NUM:
			fprintf(fptr2,"Numero\t\t - Valor: %d\n",tok->valor);
		break;
		case TOK_OP:
			fprintf(fptr2,"Operador\t - Valor: %s\n",operador_str(tok->valor));
		break;
		case TOK_PONT:
			fprintf(fptr2,"Pontuacao\t - Valor: %s\n",(tok->valor==PARESQ?"PARESQ":"PARDIR"));
		break;
		default:
			fprintf(fptr2,"Token desconhecido\n");
	}
}

void print(Tabela *t,FILE *fptr3){
	Tabela *p;
	int e=0;
	for(p=t;p!=NULL;p=p->next){
		e++;
		switch(p->tipo){
			case TOK_NUM:
				fprintf(fptr3,"\nE%d\nTok: Num\tLex: %d \tOcor: L%dC%d\n",e,p->valor,p->linha,p->coluna);
			break;
			case TOK_OP:
				fprintf(fptr3,"\nE%d\nTok: Op\tLex: %s \tOcor: L%dC%d\n",e,operador_str(p->valor),p->linha,p->coluna);
			break;
			case TOK_PONT:
				fprintf(fptr3,"\nE%d\nTok: Pont\tLex: %s \tOcor: L%dC%d\n",e,(p->valor==PARESQ?"PARESQ":"PARDIR"),p->linha,p->coluna);
			break;
			default:
				fprintf(fptr3,"\nToken desconhecido\n");
		}
	}
}

int main(void){
	FILE *fptr; //entrada.txt C�digo-Fonte
	FILE *fptr2; //saida.txt Fluxo de Tokens
	FILE *fptr3; //tabela.txt Tabela de S�mbolos



	if((fptr=fopen("entrada.txt","r"))==NULL){
		puts("N�o foi poss�vel abrir o arquivo\n\n");
		exit(1);
	}

	fptr2=fopen("saida.txt","w");
	fptr3=fopen("tabela.txt","w");

	printf("Grande Analisador Lexico das turmas 4EC\n\n");
	printf("Lendo Codigo-Fonte...\n\n");

	char entrada[200];
	Token tok;

	fgets(entrada,200,fptr);

	inicializa_analise(entrada);

	while(proximo_token(&tok)!=NULL){
		imprime_token(&tok,fptr2);
	}

	print(t,fptr3);

	fclose(fptr);
	fclose(fptr2);
	fclose(fptr3);

	printf("\n\nAnalise Lexica finalizada com sucesso\n\n");
	return 0;
}

